package com.zyz.serviceverificationcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceVerificationcodeApplicationTests {

    @Test
    void contextLoads() {
    }

}
